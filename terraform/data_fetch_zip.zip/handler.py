from fetchers import fetch_schedule_df, fetch_game_info, fetch_batter_pitcher_boxscore, fetch_playbyplay_data, send_metrics_to_cloudwatch
from datetime import datetime, timedelta
import json
from time import sleep
import requests
import pandas as pd
import json
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    date = (datetime.now() + timedelta(days=-1)).strftime('%Y-%m-%d')
    year = datetime.now().year
    
    # Results dictionary to track everything
    results = {}
    
    # Step 1: Fetch schedule
    schedule_df, schedule_errors = fetch_schedule_df(date)
    results['schedule'] = {
        'games_found': len(schedule_df),
        'errors': len(schedule_errors)
    }
    
    if schedule_df.empty:
        results['message'] = 'No games on schedule date,'
        return {'statusCode': 200, 'body': json.dumps(results)}
    
    logger.info(f"Processing date: {date}")
    logger.info(f"Schedule fetched: {len(schedule_df)} games, {len(schedule_errors)} errors")

    # Extract gamepks from schedule
    gamepks = schedule_df['game_id'].tolist()
    
    # Fetch game info
    game_df, game_errors = fetch_game_info(gamepks, game_date=date)
    results['game_info'] = {
        'games_processed': len(game_df['gamePk'].unique()) if not game_df.empty else 0,
        'errors': len(game_errors)
    }

    logger.info(f"Game info fetched: {game_df['gamePk'].unique()} games, {len(game_errors)} errors")

    
    # Extract boxscore
    try:
        batter_df, pitcher_df, boxscore_errors = fetch_batter_pitcher_boxscore(gamepks, game_date=date)
        results['boxscore'] = {
            'batters_boxscore_processed': len(batter_df['gamePk'].unique()),
            'pitchers_boxscore_processed': len(pitcher_df['gamePk'].unique()),
            'errors': len(boxscore_errors)
        }
        logger.info(f"Boxscores fetched. Batter: {batter_df['gamePk'].unique()} games, Pitcher: {pitcher_df['gamePk'].unique()} games, {len(boxscore_errors)} errors")

    except KeyError as e:
        print(f"KeyError in fetch_batter_pitcher_boxscore: {e}")
        results['boxscore'] = {
            'batters_boxscore_processed': 0,
            'pitchers_boxscore_processed': 0,
            'errors': 1,
            'error_message': f"Missing column: {str(e)}"
        }

    playbplay_df, playbplay_errors = fetch_playbyplay_data(gamepks, game_date=date)
    
    results['playbyplay'] = {
        'games_processed': len(playbplay_df['gamepk'].unique()),
        'errors': len(playbplay_errors)
    }
    
    logger.info(f"Boxscores fetched. Batter: {playbplay_df['gamepk'].unique()} {len(playbplay_errors)} errors")

    
    # Log final results
    logger.info(f"Final results: {json.dumps(results, indent=2)}")
    
    # Send metrics to CloudWatch
    send_metrics_to_cloudwatch(results, date)
    
    return {
        'statusCode': 200,
        'body': json.dumps(results)
    }

