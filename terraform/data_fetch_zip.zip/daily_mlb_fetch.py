import os
import pandas as pd
import statsapi
from tqdm import tqdm
from math import ceil
from time import sleep
from datetime import datetime, timedelta
from typing import Optional, List, Union
import boto3
from botocore.exceptions import ClientError
import tempfile
import logging
import requests
import boto3

cloudwatch = boto3.client('cloudwatch', region_name='us-east-2')



def _upload_to_s3(df, s3_key):

    aws_bucket = 'mlbdk'
    aws_region='us-east-1'

    s3_client = boto3.client('s3', region_name=aws_region)
    try:
        # Use temporary file for parquet upload
        with tempfile.NamedTemporaryFile(suffix='.parquet', delete=False) as temp_file:
            df.to_parquet(temp_file.name, index=False)
            s3_client.upload_file(temp_file.name, aws_bucket, s3_key)
            # Clean up temp file
            os.unlink(temp_file.name)
    
    except ClientError as e:
        error_msg = f"Error uploading to S3: {e}"
        raise

def fetch_schedule_df(date: str,
                      sleep_time: Optional[float] = 1.1,
                      save_to_s3: bool = True,
                      year_folder: int = datetime.now().year):
    """
    Fetch MLB schedule data for a single date
    
    Args:
        date (str): Date in 'YYYY-MM-DD' format
        sleep_time (float): Seconds to wait (mainly for consistency with other functions)
        save_to_s3 (bool): Whether to save to S3
    
    Returns:
        tuple: (DataFrame, list of errors)
    """
    
    def process_schedule_dataframe(schedule_list):
        """Clean and process the combined schedule DataFrame"""
        final_df = pd.concat(schedule_list, ignore_index=True)
        
        # Data type conversions (safe conversions with error handling)
        int_cols = ['away_score', 'home_score']
        for col in int_cols:
            if col in final_df.columns:
                final_df[col] = pd.to_numeric(final_df[col], errors='coerce').fillna(0).astype(int)
        
        str_cols = ['game_id', 'away_id', 'home_id', 'venue_id', 'current_inning']
        for col in str_cols:
            if col in final_df.columns:
                final_df[col] = final_df[col].astype(str)
        
        # Add metadata
        final_df['data_fetched_at'] = datetime.now().isoformat()
        
        # Sort by game date and game_id for consistency
        if 'game_date' in final_df.columns:
            final_df = final_df.sort_values(['game_date', 'game_id']).reset_index(drop=True)
        
        return final_df
    
    
    complete_schedule_list = []
    error_list = []
    
    try:
        print(f"Fetching schedule for {date}")
        schedule_data = statsapi.schedule(date=date)
        
        if schedule_data:
            schedule_df = pd.DataFrame(schedule_data)
            complete_schedule_list.append(schedule_df)
        else:
            print(f"No games found for {date}")
            
    except Exception as e:
        error_list.append(date)
        error_msg = f"Failed to get schedule for {date}: {e}"
        print(error_msg)
    
    # Optional sleep (mainly for consistency with other functions)
    if sleep_time:
        sleep(sleep_time)
    
    # Process and save final data
    if complete_schedule_list:
        final_df = process_schedule_dataframe(complete_schedule_list)
        
        # Save final file
        if save_to_s3:
            s3_key = f"raw_data/games/schedule/{year_folder}/schedule_{date}.parquet"
            _upload_to_s3(final_df, s3_key)
        
        return final_df, error_list
    else:
        print("No schedule data was successfully fetched.")
        return pd.DataFrame(), error_list
    
def fetch_game_info(gamepks: list[int],
                    game_date: str,
                    sleep_time: Optional[float] = 1.1,
                    save_to_s3: bool = True,
                    year_folder: int = datetime.now().year):

    def process_game_data(game_dict):

        rel_game_cols = ['game_type','game_doubleHeader','game_id','game_gamedayType','game_tiebreaker',
            'game_gameNumber','game_calendarEventID','game_season','game_seasonDisplay']
        rel_status_cols = ['status_statusCode', 'status_startTimeTBD']

        game = pd.json_normalize(game_dict['gameData']['game']).add_prefix('game_')
        game = game[rel_game_cols]

        status = pd.json_normalize(game_dict['gameData']['status']).add_prefix('status_')
        status = status[rel_status_cols]

        weather = pd.json_normalize(game_dict['gameData']['weather']).add_prefix('weather_')

        try:
            probable_pitchers_away = pd.json_normalize(game_dict['gameData']['probablePitchers']['away']).add_prefix('probable_pitcher_away_')
            probable_pitchers_away = probable_pitchers_away[['probable_pitcher_away_id', 'probable_pitcher_away_fullName']]
        except KeyError:
            probable_pitchers_away = pd.DataFrame({
                'probable_pitcher_away_id': [None], 
                'probable_pitcher_away_fullName': [None]
            })

        try:   
            probable_pitchers_home = pd.json_normalize(game_dict['gameData']['probablePitchers']['home']).add_prefix('probable_pitcher_home_')
            probable_pitchers_home = probable_pitchers_home[['probable_pitcher_home_id', 'probable_pitcher_home_fullName']]
        except KeyError:
            probable_pitchers_home = pd.DataFrame({
                'probable_pitcher_home_id': [None], 
                'probable_pitcher_home_fullName': [None]
            })
            
        game_df = pd.concat([game, status, weather, probable_pitchers_away, probable_pitchers_home], axis=1)
        game_df['game_duration_minutes'] = game_dict['gameData']['gameInfo']['gameDurationMinutes']
        game_df['gamePk'] = game_dict['gamePk']

        return game_df 

    game_df_list = []
    gamepk_errors = []
    
    for gamepk in tqdm(gamepks, desc="Fetching games"):
        try:
            game_dict = statsapi.get('game',{'gamePk':gamepk})
            game_df = process_game_data(game_dict)
            game_df_list.append(game_df)
            sleep(sleep_time)

        except (requests.RequestException, KeyError, ValueError) as e:
            gamepk_errors.append(gamepk)
            print(f"Error fetching game {gamepk}: {e}")
            continue

    game_df_combined = pd.concat(game_df_list, ignore_index=True)
    
    if save_to_s3:

        # Save to AWS S3
        s3_key = f"raw_data/games/game_info/{year_folder}/game_info_{game_date}.parquet"
        _upload_to_s3(game_df_combined, s3_key)

    return game_df_combined, gamepk_errors

def fetch_batter_pitcher_boxscore(gamepks: list[int],
                                game_date: str,
                                save_to_s3=True,
                                year_folder: int = datetime.now().year):
    
    def process_players_boxscore(boxscore_dict):

        results = {'batters':[], 'pitchers':[]}

        for player_type in ['Batters','Pitchers']:
            for side in ['home', 'away']:
                players = pd.DataFrame(boxscore_dict[f'{side}{player_type}'][1:])

                players['team_id'] = boxscore_dict['teamInfo'][f'{side}']['id']
                players['team_name'] = boxscore_dict['teamInfo'][f'{side}']['teamName']

                results[player_type.lower()].append(players)

            
        batters_df = pd.concat(results['batters'], ignore_index=True)
        pitchers_df = pd.concat(results['pitchers'], ignore_index=True)

        return batters_df, pitchers_df

    batter_df_list = []
    pitcher_df_list = []
    gamepk_errors = []

    for gamepk in tqdm(gamepks, desc='Fetching boxscores'):
        try:
            boxscore_dict =  statsapi.boxscore_data(gamepk, timecode=None)
            batters_df, pitchers_df = process_players_boxscore(boxscore_dict)   
            
            batters_df['gamePk'] = gamepk 
            pitchers_df['gamePk'] = gamepk 

            batter_df_list.append(batters_df)
            pitcher_df_list.append(pitchers_df)

        except (requests.RequestException, KeyError, ValueError) as e:
            gamepk_errors.append(gamepk)
            print(f"Error fetching game {gamepk}: {e}")
            continue
    
    batter_df_complete = pd.concat(batter_df_list, ignore_index=True)
    pitcher_df_complete = pd.concat(pitcher_df_list, ignore_index=True)

    if save_to_s3:

        # Save to AWS S3
        s3_batter_key = f"raw_data/games/batter_boxscore/{year_folder}/batter_boxscore_{game_date}.parquet"
        s3_pitcher_key = f"raw_data/games/pitcher_boxscore/{year_folder}/pitcher_boxscore_{game_date}.parquet"
        
        _upload_to_s3(batter_df_complete, s3_batter_key)
        _upload_to_s3(pitcher_df_complete, s3_pitcher_key)

    return batter_df_complete, pitcher_df_complete, gamepk_errors

def fetch_playbyplay_data(gamepks: List,
                            game_date: str,
                            sleep_time: Optional[float] = 1.1,
                            save_to_s3: bool = True,
                            year_folder: str = datetime.now().year):
    """
    Fetch Statcast data for a single date
    
    Args:
        gamepks: List
        sleep_time (float): Seconds to wait after API call
        save_to_s3 (bool): Whether to save final results to S3
    
    Returns:
        tuple: (DataFrame, list of errors)
    """
    
    def parse_plays_to_dataframe(all_plays):
        rows = []
        
        for play in all_plays:
            # Get the main play info
            result = play.get('result', {})
            about = play.get('about', {})
            count = play.get('count', {})
            matchup = play.get('matchup', {})
            play_events = play.get('playEvents', [])
            
            # Extract each pitch/event
            for event in play_events:
                if event.get('type') != 'pitch' or not event.get('isPitch'):
                    continue  # Skip non-pitch events
                    
                row = {
                    # Play-level info
                    'play_id': about.get('atBatIndex'),
                    'inning': about.get('inning'),
                    'half_inning': about.get('halfInning'),
                    'batter_id': matchup.get('batter', {}).get('id'),
                    'batter_name': matchup.get('batter', {}).get('fullName'),
                    'pitcher_id': matchup.get('pitcher', {}).get('id'),
                    'pitcher_name': matchup.get('pitcher', {}).get('fullName'),
                    'play_result': result.get('event'),
                    'play_description': result.get('description'),
                    
                    # Event-level info
                    'event_index': event.get('index'),
                    'event_type': event.get('type'),
                    'is_pitch': event.get('isPitch'),
                    'pitch_number': event.get('pitchNumber'),
                    
                    # Pitch details
                    'pitch_call': event.get('details', {}).get('call', {}).get('description'),
                    'pitch_call_code': event.get('details', {}).get('call', {}).get('code'),
                    'pitch_type': event.get('details', {}).get('type', {}).get('description'),
                    'pitch_type_code': event.get('details', {}).get('type', {}).get('code'),
                    'is_in_play': event.get('details', {}).get('isInPlay'),
                    'is_strike': event.get('details', {}).get('isStrike'),
                    'is_ball': event.get('details', {}).get('isBall'),
                    'is_out': event.get('details', {}).get('isOut'),
                    'count_balls': event.get('count', {}).get('balls'),
                    'count_strikes': event.get('count', {}).get('strikes'),
                    'count_outs': event.get('count', {}).get('outs'),
                }
                
                # Add pitch data if available
                if event.get('pitchData'):
                    pitch_data = event['pitchData']
                    coordinates = pitch_data.get('coordinates', {})
                    breaks = pitch_data.get('breaks', {})
                    
                    row.update({
                        # Basic pitch metrics
                        'start_speed': pitch_data.get('startSpeed'),
                        'end_speed': pitch_data.get('endSpeed'),
                        'zone': pitch_data.get('zone'),
                        'type_confidence': pitch_data.get('typeConfidence'),
                        'plate_time': pitch_data.get('plateTime'),
                        'extension': pitch_data.get('extension'),
                        'strike_zone_top': pitch_data.get('strikeZoneTop'),
                        'strike_zone_bottom': pitch_data.get('strikeZoneBottom'),
                        
                        # Coordinates
                        'plate_x': coordinates.get('pX'),
                        'plate_z': coordinates.get('pZ'),
                        'release_pos_x': coordinates.get('x0'),
                        'release_pos_y': coordinates.get('y0'),
                        'release_pos_z': coordinates.get('z0'),
                        'pfx_x': coordinates.get('pfxX'),
                        'pfx_z': coordinates.get('pfxZ'),
                        'vx0': coordinates.get('vX0'),
                        'vy0': coordinates.get('vY0'),
                        'vz0': coordinates.get('vZ0'),
                        'ax': coordinates.get('aX'),
                        'ay': coordinates.get('aY'),
                        'az': coordinates.get('aZ'),
                        'sz_x': coordinates.get('x'),
                        'sz_y': coordinates.get('y'),
                        
                        # Breaks
                        'spin_rate': breaks.get('spinRate'),
                        'spin_direction': breaks.get('spinDirection'),
                        'break_angle': breaks.get('breakAngle'),
                        'break_length': breaks.get('breakLength'),
                        'break_y': breaks.get('breakY'),
                        'break_vertical': breaks.get('breakVertical'),
                        'break_vertical_induced': breaks.get('breakVerticalInduced'),
                        'break_horizontal': breaks.get('breakHorizontal'),
                    })
                
                # Add hit data if available
                if event.get('hitData'):
                    hit_data = event['hitData']
                    hit_coords = hit_data.get('coordinates', {})
                    row.update({
                        'launch_speed': hit_data.get('launchSpeed'),
                        'launch_angle': hit_data.get('launchAngle'),
                        'total_distance': hit_data.get('totalDistance'),
                        'trajectory': hit_data.get('trajectory'),
                        'hardness': hit_data.get('hardness'),
                        'hit_location': hit_data.get('location'),
                        'hit_coord_x': hit_coords.get('coordX'),
                        'hit_coord_y': hit_coords.get('coordY')
                    })
                
                rows.append(row)
        
        return pd.DataFrame(rows)
    
    gamepk_error_list = []
    playbyplay_list = []
    for gamepk in gamepks:
        try: 
            url = f"https://statsapi.mlb.com/api/v1/game/{gamepk}/playByPlay"
            response = requests.get(url)
            response = response.json()
            playbyplay_df = parse_plays_to_dataframe(response['allPlays'])
            playbyplay_df['gamepk'] = gamepk

            playbyplay_list.append(playbyplay_df)
            sleep(1.1)
        except Exception as e:
            gamepk_error_list.append(gamepk)
            error_msg = f"Failed to get Statcast data for {gamepk}: {e}"
            print(error_msg)

    
    if playbyplay_list:
        complete_df = pd.concat(playbyplay_list)
        
        if save_to_s3:
            s3_key = f"raw_data/playbyplay/{year_folder}/playbyplay_{game_date}.parquet"
            _upload_to_s3(complete_df, s3_key)
        
        return complete_df, gamepk_error_list
    else:
        print("No Statcast data was successfully fetched.")
        return pd.DataFrame(), gamepk_error_list
    



def send_metrics_to_cloudwatch(results, date):
    """Send custom metrics to CloudWatch for dashboard visualization"""
    metrics = []
    
    # Schedule metrics
    if 'schedule' in results:
        metrics.extend([
            {
                'MetricName': 'ScheduleGamesFound',
                'Value': results['schedule']['games_found'],
                'Unit': 'Count',
                'Dimensions': [{'Name': 'ProcessDate', 'Value': date}]
            },
            {
                'MetricName': 'ScheduleErrors',
                'Value': results['schedule']['errors'],
                'Unit': 'Count',
                'Dimensions': [{'Name': 'ProcessDate', 'Value': date}]
            }
        ])
    
    # Game info metrics
    if 'game_info' in results:
        metrics.extend([
            {
                'MetricName': 'GameInfoProcessed',
                'Value': results['game_info']['games_processed'],
                'Unit': 'Count',
                'Dimensions': [{'Name': 'ProcessDate', 'Value': date}]
            },
            {
                'MetricName': 'GameInfoErrors',
                'Value': results['game_info']['errors'],
                'Unit': 'Count',
                'Dimensions': [{'Name': 'ProcessDate', 'Value': date}]
            }
        ])
    
    # Boxscore metrics
    if 'boxscore' in results:
        metrics.extend([
            {
                'MetricName': 'BattersBoxscoreProcessed',
                'Value': results['boxscore']['batters_boxscore_processed'],
                'Unit': 'Count',
                'Dimensions': [{'Name': 'ProcessDate', 'Value': date}]
            },
            {
                'MetricName': 'PitchersBoxscoreProcessed',
                'Value': results['boxscore']['pitchers_boxscore_processed'],
                'Unit': 'Count',
                'Dimensions': [{'Name': 'ProcessDate', 'Value': date}]
            },
            {
                'MetricName': 'BoxscoreErrors',
                'Value': results['boxscore']['errors'],
                'Unit': 'Count',
                'Dimensions': [{'Name': 'ProcessDate', 'Value': date}]
            }
        ])
    
    # Play-by-play metrics
    if 'playbyplay' in results:
        metrics.extend([
            {
                'MetricName': 'PlayByPlayProcessed',
                'Value': results['playbyplay']['games_processed'],
                'Unit': 'Count',
                'Dimensions': [{'Name': 'ProcessDate', 'Value': date}]
            },
            {
                'MetricName': 'PlayByPlayErrors',
                'Value': results['playbyplay']['errors'],
                'Unit': 'Count',
                'Dimensions': [{'Name': 'ProcessDate', 'Value': date}]
            }
        ])
    
    # Send metrics in batches (CloudWatch allows max 20 per call)
    for i in range(0, len(metrics), 20):
        batch = metrics[i:i+20]
        try:
            cloudwatch.put_metric_data(
                Namespace='mlb/DataProcessing',
                MetricData=batch
            )
        except Exception as e:
            error_msg = f"Failed to send metrics batch: {e}"
            print(error_msg)
